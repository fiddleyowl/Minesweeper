package Extensions.TypeCasting;

import java.util.Arrays;

public class CastString {
    public static String String(Object i) { return i.toString(); }

    public static String String(boolean[] i) { return Arrays.toString(i); }

    public static String String(byte[] i) { return Arrays.toString(i); }

    public static String String(short[] i) { return Arrays.toString(i); }

    public static String String(int[] i) { return Arrays.toString(i); }

    public static String String(long[] i) { return Arrays.toString(i); }

    public static String String(float[] i) { return Arrays.toString(i); }

    public static String String(double[] i) { return Arrays.toString(i); }

    public static String String(char[] i) { return Arrays.toString(i); }

    public static String String(Character[] i) { return Arrays.toString(i); }

    public static String String(String[] i) { return Arrays.toString(i); }

    public static String String(Object[] i) { return Arrays.deepToString(i); }

}
